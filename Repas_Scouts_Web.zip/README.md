# Repas SGDF — application web

Application statique issue du classeur Excel `Repas_SGDF.xlsx`.

## Fonctionnalités
- gestion des participants par tranche d'âge ;
- calcul automatique du nombre de portions adultes équivalentes ;
- création/modification/suppression de plats ;
- bibliothèque de  ingrédients et familles ;
- construction du menu par jour et par repas ;
- génération automatique de la liste de courses, regroupée par famille ;
- affichage d'une recette avec quantités adaptées au camp ;
- sauvegarde locale dans le navigateur ;
- import/export d'un fichier JSON pour partager ou sauvegarder les données.

## Mise en ligne
Le dossier peut être publié tel quel sur un hébergeur de site statique (GitHub Pages, Netlify, Vercel, etc.). Il ne nécessite ni serveur ni base de données pour la version actuelle.
